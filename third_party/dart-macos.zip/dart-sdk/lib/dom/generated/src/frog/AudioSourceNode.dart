
class AudioSourceNodeJs extends AudioNodeJs implements AudioSourceNode native "*AudioSourceNode" {
}
