
class SVGFEDistantLightElementJs extends SVGElementJs implements SVGFEDistantLightElement native "*SVGFEDistantLightElement" {

  SVGAnimatedNumberJs get azimuth() native "return this.azimuth;";

  SVGAnimatedNumberJs get elevation() native "return this.elevation;";
}
