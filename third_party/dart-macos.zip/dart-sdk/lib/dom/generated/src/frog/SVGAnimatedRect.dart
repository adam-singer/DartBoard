
class SVGAnimatedRectJs extends DOMTypeJs implements SVGAnimatedRect native "*SVGAnimatedRect" {

  SVGRectJs get animVal() native "return this.animVal;";

  SVGRectJs get baseVal() native "return this.baseVal;";
}
