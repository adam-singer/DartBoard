
class ClientRectJs extends DOMTypeJs implements ClientRect native "*ClientRect" {

  num get bottom() native "return this.bottom;";

  num get height() native "return this.height;";

  num get left() native "return this.left;";

  num get right() native "return this.right;";

  num get top() native "return this.top;";

  num get width() native "return this.width;";
}
