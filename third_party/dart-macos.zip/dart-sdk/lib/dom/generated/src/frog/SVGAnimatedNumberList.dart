
class SVGAnimatedNumberListJs extends DOMTypeJs implements SVGAnimatedNumberList native "*SVGAnimatedNumberList" {

  SVGNumberListJs get animVal() native "return this.animVal;";

  SVGNumberListJs get baseVal() native "return this.baseVal;";
}
