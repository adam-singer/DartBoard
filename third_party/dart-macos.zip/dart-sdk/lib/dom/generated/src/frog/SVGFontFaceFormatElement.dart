
class SVGFontFaceFormatElementJs extends SVGElementJs implements SVGFontFaceFormatElement native "*SVGFontFaceFormatElement" {
}
