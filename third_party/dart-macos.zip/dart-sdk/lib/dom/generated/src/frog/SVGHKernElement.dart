
class SVGHKernElementJs extends SVGElementJs implements SVGHKernElement native "*SVGHKernElement" {
}
