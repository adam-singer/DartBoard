
class IDBAnyJs extends DOMTypeJs implements IDBAny native "*IDBAny" {
}
