
class SVGGlyphElementJs extends SVGElementJs implements SVGGlyphElement native "*SVGGlyphElement" {
}
