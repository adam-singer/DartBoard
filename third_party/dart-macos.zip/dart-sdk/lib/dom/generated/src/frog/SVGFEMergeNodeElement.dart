
class SVGFEMergeNodeElementJs extends SVGElementJs implements SVGFEMergeNodeElement native "*SVGFEMergeNodeElement" {

  SVGAnimatedStringJs get in1() native "return this.in1;";
}
