
class CanvasRenderingContextJs extends DOMTypeJs implements CanvasRenderingContext native "*CanvasRenderingContext" {

  HTMLCanvasElementJs get canvas() native "return this.canvas;";
}
