
class HTMLAudioElementJs extends HTMLMediaElementJs implements HTMLAudioElement native "*HTMLAudioElement" {
}
