
class SVGExternalResourcesRequiredJs extends DOMTypeJs implements SVGExternalResourcesRequired native "*SVGExternalResourcesRequired" {

  SVGAnimatedBooleanJs get externalResourcesRequired() native "return this.externalResourcesRequired;";
}
