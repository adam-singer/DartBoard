
class HTMLTableCaptionElementJs extends HTMLElementJs implements HTMLTableCaptionElement native "*HTMLTableCaptionElement" {

  String get align() native "return this.align;";

  void set align(String value) native "this.align = value;";
}
