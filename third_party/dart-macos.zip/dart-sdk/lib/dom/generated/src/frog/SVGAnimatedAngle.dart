
class SVGAnimatedAngleJs extends DOMTypeJs implements SVGAnimatedAngle native "*SVGAnimatedAngle" {

  SVGAngleJs get animVal() native "return this.animVal;";

  SVGAngleJs get baseVal() native "return this.baseVal;";
}
