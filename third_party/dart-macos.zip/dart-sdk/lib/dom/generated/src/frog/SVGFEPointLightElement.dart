
class SVGFEPointLightElementJs extends SVGElementJs implements SVGFEPointLightElement native "*SVGFEPointLightElement" {

  SVGAnimatedNumberJs get x() native "return this.x;";

  SVGAnimatedNumberJs get y() native "return this.y;";

  SVGAnimatedNumberJs get z() native "return this.z;";
}
