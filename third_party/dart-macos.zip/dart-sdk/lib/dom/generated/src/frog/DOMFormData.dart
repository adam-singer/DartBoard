
class DOMFormDataJs extends DOMTypeJs implements DOMFormData native "*DOMFormData" {

  void append(String name, String value, String filename) native;
}
