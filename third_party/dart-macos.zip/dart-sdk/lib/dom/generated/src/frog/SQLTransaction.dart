
class SQLTransactionJs extends DOMTypeJs implements SQLTransaction native "*SQLTransaction" {
}
