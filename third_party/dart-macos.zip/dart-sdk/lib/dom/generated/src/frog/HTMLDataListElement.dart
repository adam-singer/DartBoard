
class HTMLDataListElementJs extends HTMLElementJs implements HTMLDataListElement native "*HTMLDataListElement" {

  HTMLCollectionJs get options() native "return this.options;";
}
