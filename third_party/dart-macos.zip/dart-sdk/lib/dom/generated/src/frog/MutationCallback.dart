
class MutationCallbackJs extends DOMTypeJs implements MutationCallback native "*MutationCallback" {
}
