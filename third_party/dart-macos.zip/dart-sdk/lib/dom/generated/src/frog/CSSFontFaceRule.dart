
class CSSFontFaceRuleJs extends CSSRuleJs implements CSSFontFaceRule native "*CSSFontFaceRule" {

  CSSStyleDeclarationJs get style() native "return this.style;";
}
