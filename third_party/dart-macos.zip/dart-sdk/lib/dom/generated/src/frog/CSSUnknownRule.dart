
class CSSUnknownRuleJs extends CSSRuleJs implements CSSUnknownRule native "*CSSUnknownRule" {
}
