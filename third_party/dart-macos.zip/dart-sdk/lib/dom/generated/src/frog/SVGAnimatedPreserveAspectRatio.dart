
class SVGAnimatedPreserveAspectRatioJs extends DOMTypeJs implements SVGAnimatedPreserveAspectRatio native "*SVGAnimatedPreserveAspectRatio" {

  SVGPreserveAspectRatioJs get animVal() native "return this.animVal;";

  SVGPreserveAspectRatioJs get baseVal() native "return this.baseVal;";
}
