
class CDATASectionJs extends TextJs implements CDATASection native "*CDATASection" {
}
