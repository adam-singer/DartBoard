
class SVGAnimateTransformElementJs extends SVGAnimationElementJs implements SVGAnimateTransformElement native "*SVGAnimateTransformElement" {
}
