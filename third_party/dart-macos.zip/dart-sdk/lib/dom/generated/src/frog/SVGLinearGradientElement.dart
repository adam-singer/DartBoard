
class SVGLinearGradientElementJs extends SVGGradientElementJs implements SVGLinearGradientElement native "*SVGLinearGradientElement" {

  SVGAnimatedLengthJs get x1() native "return this.x1;";

  SVGAnimatedLengthJs get x2() native "return this.x2;";

  SVGAnimatedLengthJs get y1() native "return this.y1;";

  SVGAnimatedLengthJs get y2() native "return this.y2;";
}
