
class SVGFontFaceNameElementJs extends SVGElementJs implements SVGFontFaceNameElement native "*SVGFontFaceNameElement" {
}
