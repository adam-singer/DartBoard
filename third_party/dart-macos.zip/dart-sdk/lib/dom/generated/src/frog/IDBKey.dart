
class IDBKeyJs extends DOMTypeJs implements IDBKey native "*IDBKey" {
}
