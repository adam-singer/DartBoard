
class DirectoryReaderSyncJs extends DOMTypeJs implements DirectoryReaderSync native "*DirectoryReaderSync" {

  EntryArraySyncJs readEntries() native;
}
