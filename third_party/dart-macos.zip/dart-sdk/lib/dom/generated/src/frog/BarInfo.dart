
class BarInfoJs extends DOMTypeJs implements BarInfo native "*BarInfo" {

  bool get visible() native "return this.visible;";
}
