
class CanvasGradientJs extends DOMTypeJs implements CanvasGradient native "*CanvasGradient" {

  void addColorStop(num offset, String color) native;
}
