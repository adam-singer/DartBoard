
class CanvasPatternJs extends DOMTypeJs implements CanvasPattern native "*CanvasPattern" {
}
