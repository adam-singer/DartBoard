
class SVGAnimatedTransformListJs extends DOMTypeJs implements SVGAnimatedTransformList native "*SVGAnimatedTransformList" {

  SVGTransformListJs get animVal() native "return this.animVal;";

  SVGTransformListJs get baseVal() native "return this.baseVal;";
}
