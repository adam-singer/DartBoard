
class EntityReferenceJs extends NodeJs implements EntityReference native "*EntityReference" {
}
