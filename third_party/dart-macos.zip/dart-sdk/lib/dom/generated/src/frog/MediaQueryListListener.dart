
class MediaQueryListListenerJs extends DOMTypeJs implements MediaQueryListListener native "*MediaQueryListListener" {

  void queryChanged(MediaQueryListJs list) native;
}
