
class OESTextureFloatJs extends DOMTypeJs implements OESTextureFloat native "*OESTextureFloat" {
}
