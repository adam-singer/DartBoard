
class SVGAnimatedLengthJs extends DOMTypeJs implements SVGAnimatedLength native "*SVGAnimatedLength" {

  SVGLengthJs get animVal() native "return this.animVal;";

  SVGLengthJs get baseVal() native "return this.baseVal;";
}
