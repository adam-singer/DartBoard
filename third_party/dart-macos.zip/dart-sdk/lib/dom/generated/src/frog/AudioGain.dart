
class AudioGainJs extends AudioParamJs implements AudioGain native "*AudioGain" {
}
