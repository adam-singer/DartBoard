
class AudioChannelMergerJs extends AudioNodeJs implements AudioChannelMerger native "*AudioChannelMerger" {
}
