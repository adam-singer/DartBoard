
class SVGFontElementJs extends SVGElementJs implements SVGFontElement native "*SVGFontElement" {
}
