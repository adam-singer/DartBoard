
class SVGAnimatedLengthListJs extends DOMTypeJs implements SVGAnimatedLengthList native "*SVGAnimatedLengthList" {

  SVGLengthListJs get animVal() native "return this.animVal;";

  SVGLengthListJs get baseVal() native "return this.baseVal;";
}
