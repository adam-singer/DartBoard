
class CommentJs extends CharacterDataJs implements Comment native "*Comment" {
}
