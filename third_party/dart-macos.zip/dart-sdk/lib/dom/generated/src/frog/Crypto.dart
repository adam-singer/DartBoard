
class CryptoJs extends DOMTypeJs implements Crypto native "*Crypto" {

  void getRandomValues(ArrayBufferViewJs array) native;
}
